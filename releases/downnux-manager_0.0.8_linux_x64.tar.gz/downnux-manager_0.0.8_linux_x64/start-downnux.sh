#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "=========================================================="
echo " Starting DownNux Manager (Linux Portable)"
echo "=========================================================="
node scripts/serve-gui.mjs >/dev/null 2>&1 &
GUI_PID=$!
node --no-warnings apps/daemon/dist/main.mjs >/dev/null 2>&1 &
DAEMON_PID=$!

cleanup() {
  kill $GUI_PID $DAEMON_PID 2>/dev/null || true
}
trap cleanup EXIT INT TERM

sleep 1
if [ -f "scripts/downnux-desktop.py" ] && which python3 >/dev/null 2>&1; then
  python3 scripts/downnux-desktop.py
elif which xdg-open >/dev/null 2>&1; then
  xdg-open "http://localhost:1420"
  wait $DAEMON_PID
else
  echo "Open http://localhost:1420 in your browser."
  wait $DAEMON_PID
fi
